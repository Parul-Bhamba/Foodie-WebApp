import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Main from "./components/Public/Main";
import AdminPanel from './components/admin/AdminPanel';
import OwnerPage from './components/owner/OwnerPage';
import RestaurantItemsPage from './components/owner/RestaurantItemsPage';
import UserPage from './components/user/UserPage';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ToastContainer } from 'react-toastify';
import { CartProvider } from './contexts/CartContext';
import 'react-toastify/dist/ReactToastify.css'; // Ensure styles are imported

// Protected route component with role check
const ProtectedRoute = ({ children, requiredRole }) => {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" />;
  if (requiredRole && user.role !== requiredRole) return <Navigate to="/login" />;
  return children;
};

function App() {
  return (
    <div style={{ overflowX: 'hidden' }}> {/* Global overflow protection */}
      <AuthProvider>
        <CartProvider>
          <Router>
            <Routes>
              {/* Public Pages */}
              <Route path="/*" element={<Main />} />

              {/* Role-based Protected Routes */}
              <Route
                path="/admin"
                element={
                  <ProtectedRoute requiredRole="admin">
                    <AdminPanel />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/owner-page"
                element={
                  <ProtectedRoute requiredRole="owner">
                    <OwnerPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/restaurant/:id/items"
                element={
                  <ProtectedRoute requiredRole="owner">
                    <RestaurantItemsPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/user-page"
                element={
                  <ProtectedRoute requiredRole="user">
                    <UserPage />
                  </ProtectedRoute>
                }
              />
            </Routes>
            <ToastContainer position="top-right" autoClose={3000} />
          </Router>
        </CartProvider>
      </AuthProvider>
    </div>
  );
}

export default App;
